﻿using System;
using System.Net;
using System.Collections.Generic;
using HtmlAgilityPack;

namespace SpiderCSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> URLS = new List<string>();
            List<string> URLSVisitadas = new List<string>();
            List<string> BlackList = new List<string>();


            string opcao = "n";
            do{
                Console.Clear();
                CriarMenu();
                opcao = Console.ReadLine();
                if(opcao == "1" || opcao == "2" || opcao == "3"|| opcao == "4" || opcao == "5"){ //Verify if option is avaible in menu
                    
                }else{
                    opcao = "n";
                }

                switch(opcao){
                    case "1":
                        string Http = "";
                        do{
                            System.Console.WriteLine("Digite o link inicial: (Exemplo: https://www.example.com/");
                            URLS.Add(Console.ReadLine().ToString());
                            string LinkPego = URLS[0];
                            //Tratar URL

                            
                            Http = LinkPego.Substring(0,4);
                            System.Console.WriteLine("HTTP É: "+Http);

                            

                                if(Http == "http"){

                                    ChamarCrawl(URLS,URLSVisitadas,20);

                                    
                                    System.Console.WriteLine();
                                    System.Console.WriteLine();
                                    System.Console.WriteLine();
                                    System.Console.WriteLine();
                                    System.Console.WriteLine();
                                    System.Console.WriteLine("URLS VISITADAS: ");
                                    foreach(string Visitadas in URLSVisitadas){
                                        System.Console.WriteLine(Visitadas);
                                    }
                                    Console.ReadLine();
                                    break;
                                }else{
                                    System.Console.WriteLine("Seu link não contem http ou https, adicionar? (s/n)");
                                    string opcaohttp = Console.ReadLine().ToLower();

                                    switch(opcaohttp)
                                    {
                                        case "s":
                                            URLS[0] = "https://"+URLS[0]; //TODO APARTIR DAQUI ELE N FAZ NDA CONCERTAR ISSO, ELE SÓ ADICIONA E FDS
                                            Http = URLS[0].Substring(0,4);
                                            
                                            break;
                                        case "n":
                                            Http = "";
                                            break;
                                        default:
                                            System.Console.WriteLine("Opcao errada");
                                            break;
                                    }


                                }
                        }while(Http != "http");
                        ChamarCrawl(URLS,URLSVisitadas,20);
                        
                        break;
                    case "2":
                        string site = "s";
                        do{
                            System.Console.WriteLine("Digite um site para ser adicionado na BlackList ou 'sair' para sair: ");
                            site = Console.ReadLine();
                            if(site != "sair"){
                                if(site.Length > 5){
                                    VerificarSite(site);
                                    System.Console.WriteLine("Adicionar mais um site na BlackList? (s/n)");
                                }else{
                                    System.Console.WriteLine("Link do site muito curto");
                                }
                            }else{
                                System.Console.WriteLine(opcao);
                            }


                            
                        }while(site == "s");
                        

                        break;
                }
                
            }while(opcao != "n");
            






                

        }
        public static void VerificarSite(string site){
            if(site.Substring(0,8) == "https://"){
                System.Console.WriteLine("Foda-se vadia puta");
            }
            if(site.Substring(0,8) == "https://" || site.Substring(0,7) == "http://" ){
                

            }else{
                System.Console.WriteLine("Seu link não contem http ou https, adicionar? (s/n)");
                string opcaohttp = Console.ReadLine().ToLower();

                switch(opcaohttp)
                {
                    case "s":
                        site = "https://"+site; 
                        
                        break;
                    case "n":
                        break;
                    default:
                        System.Console.WriteLine("Opcao invalida");
                        break;
                }
            }
        }
        public static void ChamarCrawl(List<string> URLS, List<string> URLSVisitadas,int QuantosLinks){
            while(URLSVisitadas.Count < QuantosLinks && URLS.Count > 0){//while(URLS.Count > 0){
                try{
                    
                    Crawl(URLS,URLSVisitadas);

                }catch(Exception ex){//catch(ArgumentOutOfRangeException e){
                    //URLSVisitadas.Add(URLS[0]);
                    URLS.RemoveAt(0);
                }

            }
        }
        public static void Crawl(List<string> URLS, List<string> URLSVisitadas){
            bool encontrou = URLSVisitadas.Contains(URLS[0]);
            var wc = new WebClient();
            // for(int i = 0; i < URLSVisitadas.Count; i++){
            //     if(URLSVisitadas[i] == URLS[0]){
            //         existe = true;
            //         break;

            //     }
            // }

            if(encontrou == false){
                string pagina = wc.DownloadString(URLS[0]);
                var htmlDocument = new HtmlAgilityPack.HtmlDocument();
                htmlDocument.LoadHtml(pagina);

                
                foreach (HtmlNode link in htmlDocument.DocumentNode.SelectNodes("//a[@href]"))
                {
                    string LinkPego = link.GetAttributeValue( "href", string.Empty );
                    if(LinkPego.Length > 0){
                        string LP_PrimeiraLetra = LinkPego.Substring(0,1);
                        string LP_Http = "";
                        if(LinkPego.Length > 4){
                            LP_Http = LinkPego.Substring(0,4);
                        }
                        

                        if(LP_PrimeiraLetra == "/" && LP_PrimeiraLetra.Length > 2){
                            LinkPego = LinkPego.Remove(0,1);
                            System.Console.WriteLine(URLS[0]+LinkPego);
                            URLS.Add(LinkPego);
                        }
                        if(LP_Http == "http"){
                            System.Console.WriteLine(LinkPego);
                            URLS.Add(LinkPego);
                        }
                    }

                    
                    
                }
                URLSVisitadas.Add(URLS[0]);
                System.Console.WriteLine("Ja visitei: "+URLSVisitadas.Count+" sites");
                URLS.RemoveAt(0);
            }else{
                URLS.RemoveAt(0);
            }
        }
        public static void CriarMenu(){
            System.Console.WriteLine("           (");
            System.Console.WriteLine("           )");
            System.Console.WriteLine("     /\\  .-\"\"\"-.  /\\ ");
            System.Console.WriteLine("    //\\\\/  ,,,  \\//\\");
            System.Console.WriteLine("    |/\\| ,;;;;;, |/\\|        ");
            System.Console.WriteLine("    |/\\| ,;;;;;, |/\\|          _________      .__    .___             _________        .__                         ");
            System.Console.WriteLine("    //\\\\\\;-\"\"\"-;///\\\\         /   _____/_____ |__| __| _/___________  \\_   ___ \\  _____|  |__ _____ _____________  ");
            System.Console.WriteLine("  //  \\/   .   \\/  \\          \\_____  \\\\____ \\|  |/ __ |/ __ \\_  __ \\ /    \\  \\/ /  ___/  |  \\\\__  \\_  __ \\____  \\ ");
            System.Console.WriteLine("  (| ,-_| \\ | / |_-, |)       /        \\  |_> >  / /_/ \\  ___/|  | \\/ \\     \\____\\___ \\|   Y  \\/ __ \\|  | \\/  |_> >");
            System.Console.WriteLine("  //`__\\.-.-./__`\\\\          /_______  /   __/|__\\____ |\\___  >__|     \\______  /____  >___|  (____  /__|  |   __/ ");
            System.Console.WriteLine("  // /.-(() ())-.\\ \\\\                \\/|__|           \\/    \\/                \\/     \\/     \\/     \\/      |__|");
            System.Console.WriteLine("  // /.-(() ())-.\\ \\\\       ");
            System.Console.WriteLine(" (\\ |)   '---'   (| /)                                   Created by: André S. Azevedo");
            System.Console.WriteLine(" ` (|             |) `");
            System.Console.WriteLine("  \\)             (/");
            System.Console.WriteLine("");
            System.Console.WriteLine("");
            System.Console.WriteLine("");
            System.Console.WriteLine("                                                          1- Start");
            System.Console.WriteLine("                                                          2- Add site in blacklist");
            System.Console.WriteLine("                                                          3- Add timer");
            System.Console.WriteLine("                                                          4- Exit");








                                                                                      
                                                                                      
                                                                                      
                                                                                      
                                                                                      
                                                                                      



        }
    }
}

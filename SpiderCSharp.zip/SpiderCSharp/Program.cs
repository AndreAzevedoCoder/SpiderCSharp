﻿using System;
using System.Net;
using System.Collections.Generic;
using HtmlAgilityPack;

namespace SpiderCSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> URLS = new List<string>();
            List<string> URLSVisitadas = new List<string>();




            System.Console.WriteLine("Digite o link inicial: ");
            URLS.Add(Console.ReadLine().ToString());
            System.Console.WriteLine("Link inicial: "+URLS[0]);
            while(URLSVisitadas.Count < 10 && URLS.Count > 0){//while(URLS.Count > 0){
                try{
                    Crawl(URLS,URLSVisitadas);

                }catch(Exception ex){//catch(ArgumentOutOfRangeException e){
                    //URLSVisitadas.Add(URLS[0]);
                    URLS.RemoveAt(0);
                }

            }
            System.Console.WriteLine();
            System.Console.WriteLine();
            System.Console.WriteLine();
            System.Console.WriteLine();
            System.Console.WriteLine();
            System.Console.WriteLine("URLS VISITADAS: ");
            foreach(string Visitadas in URLSVisitadas){
                System.Console.WriteLine(Visitadas);
            }
        }
        public static void Crawl(List<string> URLS, List<string> URLSVisitadas){
            bool encontrou = URLSVisitadas.Contains(URLS[0]);
            var wc = new WebClient();
            // for(int i = 0; i < URLSVisitadas.Count; i++){
            //     if(URLSVisitadas[i] == URLS[0]){
            //         existe = true;
            //         break;

            //     }
            // }

            if(encontrou == false){
                string pagina = wc.DownloadString(URLS[0]);
                var htmlDocument = new HtmlAgilityPack.HtmlDocument();
                htmlDocument.LoadHtml(pagina);

                
                foreach (HtmlNode link in htmlDocument.DocumentNode.SelectNodes("//a[@href]"))
                {
                    string LinkPego = link.GetAttributeValue( "href", string.Empty );
                    if(LinkPego.Length > 0){
                        string LP_PrimeiraLetra = LinkPego.Substring(0,1);
                        string LP_Http = "";
                        if(LinkPego.Length > 4){
                            LP_Http = LinkPego.Substring(0,4);
                        }
                        

                        if(LP_PrimeiraLetra == "/" && LP_PrimeiraLetra.Length > 2){
                            LinkPego = LinkPego.Remove(0,1);
                            System.Console.WriteLine(URLS[0]+LinkPego);
                            URLS.Add(LinkPego);
                        }
                        if(LP_Http == "http"){
                            System.Console.WriteLine(LinkPego);
                            URLS.Add(LinkPego);
                        }
                    }

                    
                    
                }
                URLSVisitadas.Add(URLS[0]);
                System.Console.WriteLine("Ja visitei: "+URLSVisitadas.Count+" sites");
                URLS.RemoveAt(0);
            }else{
                URLS.RemoveAt(0);
            }
        }
    }
}

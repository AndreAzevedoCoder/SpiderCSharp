﻿using System;
using System.Net;
using System.Collections.Generic;
using HtmlAgilityPack;

namespace SpiderCSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> URLS = new List<string>();
            List<string> URLSVisitadas = new List<string>();


            string opcao = "n";
            do{
                Console.Clear();
                CriarMenu();
                opcao = Console.ReadLine();
                if(opcao == "1" || opcao == "2" || opcao == "3"|| opcao == "4" || opcao == "5"){ //Verify if option is avaible in menu
                    
                }else{
                    opcao = "n";
                }
                
            }while(opcao == "n");
            





            switch(opcao){
                case "1":
                    System.Console.WriteLine("Digite o link inicial: ");

                    //Tratar URL


                    string PrimeiraLetra = LinkPego.Substring(0,1);
                    string Http = LinkPego.Substring(0,4);

                    if(LinkPego.Length > 4){
                        LP_Http = LinkPego.Substring(0,4);
                    }
                    

                    if(LP_PrimeiraLetra == "/" && LP_PrimeiraLetra.Length > 2){
                        LinkPego = LinkPego.Remove(0,1);
                        System.Console.WriteLine(URLS[0]+LinkPego);
                        URLS.Add(LinkPego);
                    }
                    if(LP_Http == "http"){
                        System.Console.WriteLine(LinkPego);
                        URLS.Add(LinkPego);
                    }


                    if()
                    URLS.Add(Console.ReadLine().ToString());



                    System.Console.WriteLine("Link inicial: "+URLS[0]);
                    while(URLSVisitadas.Count < 10 && URLS.Count > 0){//while(URLS.Count > 0){
                        try{
                            Crawl(URLS,URLSVisitadas);

                        }catch(Exception ex){//catch(ArgumentOutOfRangeException e){
                            //URLSVisitadas.Add(URLS[0]);
                            URLS.RemoveAt(0);
                        }

                    }
                    System.Console.WriteLine();
                    System.Console.WriteLine();
                    System.Console.WriteLine();
                    System.Console.WriteLine();
                    System.Console.WriteLine();
                    System.Console.WriteLine("URLS VISITADAS: ");
                    foreach(string Visitadas in URLSVisitadas){
                        System.Console.WriteLine(Visitadas);
                    }
                    break;
            }
                

        }
        public static void Crawl(List<string> URLS, List<string> URLSVisitadas){
            bool encontrou = URLSVisitadas.Contains(URLS[0]);
            var wc = new WebClient();
            // for(int i = 0; i < URLSVisitadas.Count; i++){
            //     if(URLSVisitadas[i] == URLS[0]){
            //         existe = true;
            //         break;

            //     }
            // }

            if(encontrou == false){
                string pagina = wc.DownloadString(URLS[0]);
                var htmlDocument = new HtmlAgilityPack.HtmlDocument();
                htmlDocument.LoadHtml(pagina);

                
                foreach (HtmlNode link in htmlDocument.DocumentNode.SelectNodes("//a[@href]"))
                {
                    string LinkPego = link.GetAttributeValue( "href", string.Empty );
                    if(LinkPego.Length > 0){
                        string LP_PrimeiraLetra = LinkPego.Substring(0,1);
                        string LP_Http = "";
                        if(LinkPego.Length > 4){
                            LP_Http = LinkPego.Substring(0,4);
                        }
                        

                        if(LP_PrimeiraLetra == "/" && LP_PrimeiraLetra.Length > 2){
                            LinkPego = LinkPego.Remove(0,1);
                            System.Console.WriteLine(URLS[0]+LinkPego);
                            URLS.Add(LinkPego);
                        }
                        if(LP_Http == "http"){
                            System.Console.WriteLine(LinkPego);
                            URLS.Add(LinkPego);
                        }
                    }

                    
                    
                }
                URLSVisitadas.Add(URLS[0]);
                System.Console.WriteLine("Ja visitei: "+URLSVisitadas.Count+" sites");
                URLS.RemoveAt(0);
            }else{
                URLS.RemoveAt(0);
            }
        }
        public static void CriarMenu(){
            System.Console.WriteLine("           (");
            System.Console.WriteLine("           )");
            System.Console.WriteLine("     /\\  .-\"\"\"-.  /\\ ");
            System.Console.WriteLine("    //\\\\/  ,,,  \\//\\");
            System.Console.WriteLine("    |/\\| ,;;;;;, |/\\|        ");
            System.Console.WriteLine("    |/\\| ,;;;;;, |/\\|          _________      .__    .___             _________        .__                         ");
            System.Console.WriteLine("    //\\\\\\;-\"\"\"-;///\\\\         /   _____/_____ |__| __| _/___________  \\_   ___ \\  _____|  |__ _____ _____________  ");
            System.Console.WriteLine("  //  \\/   .   \\/  \\          \\_____  \\\\____ \\|  |/ __ |/ __ \\_  __ \\ /    \\  \\/ /  ___/  |  \\\\__  \\_  __ \\____  \\ ");
            System.Console.WriteLine("  (| ,-_| \\ | / |_-, |)       /        \\  |_> >  / /_/ \\  ___/|  | \\/ \\     \\____\\___ \\|   Y  \\/ __ \\|  | \\/  |_> >");
            System.Console.WriteLine("  //`__\\.-.-./__`\\\\          /_______  /   __/|__\\____ |\\___  >__|     \\______  /____  >___|  (____  /__|  |   __/ ");
            System.Console.WriteLine("  // /.-(() ())-.\\ \\\\                \\/|__|           \\/    \\/                \\/     \\/     \\/     \\/      |__|");
            System.Console.WriteLine("  // /.-(() ())-.\\ \\\\       ");
            System.Console.WriteLine(" (\\ |)   '---'   (| /)                                   Created by: André S. Azevedo");
            System.Console.WriteLine(" ` (|             |) `");
            System.Console.WriteLine("  \\)             (/");
            System.Console.WriteLine("");
            System.Console.WriteLine("");
            System.Console.WriteLine("");
            System.Console.WriteLine("                                                          1- Start");
            System.Console.WriteLine("                                                          2- Add site in blacklist");
            System.Console.WriteLine("                                                          3- Add timer");
            System.Console.WriteLine("                                                          4- Exit");








                                                                                      
                                                                                      
                                                                                      
                                                                                      
                                                                                      
                                                                                      



        }
    }
}
